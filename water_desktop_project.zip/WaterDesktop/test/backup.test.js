'use strict';
const test = require('node:test'), assert = require('node:assert/strict');
const fs = require('fs'), os = require('os'), path = require('path'), crypto = require('crypto');
const B = require('../backup.js');
const ID = 'water', tmp = () => fs.mkdtempSync(path.join(os.tmpdir(), 'bk-'));
const sample = () => ({ subs: Array.from({ length: 50 }, (_, i) => ({ id: i + 1, name: 'مشترك ' + i })), invs: [{ id: 1 }, { id: 2 }], reads: { 'a|2026|0': { o: 1, n: 5 } }, cfg: { price: 3 } });
const ctx = (v = '1.0.0', s = 1) => ({ appId: ID, version: v, schema: s });

test('zip: aller-retour avec binaire et gros contenu', () => {
  const big = crypto.randomBytes(200000), txt = Buffer.from('عربي ✓ '.repeat(5000));
  const z = B.readZip(B.makeZip([{ name: 'a.bin', data: big }, { name: 'b.txt', data: txt }, { name: 'vide.txt', data: Buffer.alloc(0) }]));
  assert.ok(z.get('a.bin').equals(big)); assert.ok(z.get('b.txt').equals(txt)); assert.equal(z.get('vide.txt').length, 0);
});
test('sauvegarde -> effacement -> restauration : mêmes données et mêmes comptes', () => {
  const dir = tmp(), data = JSON.stringify(sample());
  const r = B.createBackup({ data, appId: ID, version: '1.0.0', dirs: [dir] });
  assert.deepEqual(r.manifest.counts, { subs: 50, invs: 2, reads: 1, cfg: 1 });
  let live = data; live = null;                                  // « effacement »
  const v = B.verifyBackup(fs.readFileSync(r.file), ctx());
  assert.ok(v.ok, v.error); live = v.data;
  assert.equal(live, data); assert.equal(crypto.createHash('sha256').update(live).digest('hex'), r.manifest.files['data.json'].sha256);
  assert.equal(v.older, false);
});
test('zip corrompu / tronqué / bit modifié : refusé', () => {
  const dir = tmp(), r = B.createBackup({ data: JSON.stringify(sample()), appId: ID, version: '1.0.0', dirs: [dir] }), buf = fs.readFileSync(r.file);
  const flipped = Buffer.from(buf); flipped[Math.floor(buf.length / 2)] ^= 0xFF;
  assert.equal(B.verifyBackup(flipped, ctx()).ok, false);
  assert.equal(B.verifyBackup(buf.subarray(0, buf.length - 40), ctx()).ok, false);
  assert.equal(B.verifyBackup(Buffer.from('pas un zip du tout'), ctx()).ok, false);
});
test('somme de contrôle falsifiée dans le manifest : refusé', () => {
  const data = Buffer.from(JSON.stringify(sample()));
  const m = { app: ID, version: '1.0.0', schema: 1, files: { 'data.json': { sha256: 'deadbeef', bytes: data.length } } };
  const zip = B.makeZip([{ name: 'manifest.json', data: JSON.stringify(m) }, { name: 'data.json', data }]);
  const v = B.verifyBackup(zip, ctx()); assert.equal(v.ok, false); assert.match(v.error, /checksum|بصمة/);
});
test('version plus récente ou autre application : refusé', () => {
  const dir = tmp(), data = JSON.stringify(sample());
  const newer = B.createBackup({ data, appId: ID, version: '2.0.0', schema: 2, dirs: [dir] });
  const v = B.verifyBackup(fs.readFileSync(newer.file), ctx('1.0.0', 1)); assert.equal(v.ok, false); assert.match(v.error, /أحدث/);
  const other = B.createBackup({ data, appId: 'transport', version: '1.0.0', dirs: [dir] });
  assert.equal(B.verifyBackup(fs.readFileSync(other.file), ctx()).ok, false);
});
test('ancienne version : acceptée et signalée (migration au chargement)', () => {
  const dir = tmp(), old = { subs: [], reads: {}, invs: [], sid: 0, seq: 0, cfg: { price: 3 } };   // sans fin/users/...
  const r = B.createBackup({ data: JSON.stringify(old), appId: ID, version: '0.9.0', schema: 0, dirs: [dir] });
  const v = B.verifyBackup(fs.readFileSync(r.file), ctx('1.2.0', 1)); assert.ok(v.ok); assert.equal(v.older, true);
});
test('second dossier en panne : la sauvegarde principale réussit avec avertissement', () => {
  const dir = tmp(), bad = path.join(tmp(), 'f'); fs.writeFileSync(bad, 'x');       // un fichier à la place d'un dossier
  const r = B.createBackup({ data: JSON.stringify(sample()), appId: ID, version: '1.0.0', dirs: [dir, path.join(bad, 'sous')] });
  assert.equal(r.files.length, 1); assert.equal(r.warnings.length, 1);
  assert.throws(() => B.createBackup({ data: JSON.stringify(sample()), appId: ID, version: '1.0.0', dirs: [path.join(bad, 'x')] }));
});
test('données vides ou invalides : refusées', () => {
  assert.throws(() => B.createBackup({ data: '', appId: ID, version: '1.0.0', dirs: [tmp()] }));
  assert.throws(() => B.createBackup({ data: '{pas json', appId: ID, version: '1.0.0', dirs: [tmp()] }));
});
test('rétention : garde N quotidiennes + 1 par mois, jamais la dernière', () => {
  const dir = tmp(), data = JSON.stringify(sample());
  for (let i = 0; i < 40; i++) B.createBackup({ data, appId: ID, version: '1.0.0', dirs: [dir], now: new Date(2026, 0, 1 + i, 10) });     // 40 jours : janv.-févr.
  const gone = B.prune(dir, ID, { daily: 5, monthly: 2 }), left = B.listBackups(dir, ID);
  assert.ok(gone.length > 0); assert.equal(left[0].day, '20260209');                   // la plus récente est conservée
  assert.ok(left.length >= 5 && left.length <= 7);                                       // 5 récentes + fin janvier
  assert.ok(left.some(x => x.day.startsWith('202601')));                                 // un représentant mensuel de janvier
});
test('rétention : les sauvegardes « pre-… » sont suivies à part', () => {
  const dir = tmp(), data = JSON.stringify(sample());
  for (let i = 0; i < 8; i++) B.createBackup({ data, appId: ID, version: '1.0.0', reason: 'pre-restore', dirs: [dir], now: new Date(2026, 2, 1 + i) });
  B.createBackup({ data, appId: ID, version: '1.0.0', reason: 'manual', dirs: [dir], now: new Date(2026, 2, 20) });
  B.prune(dir, ID, { daily: 1, monthly: 1, pre: 3 });
  const L = B.listBackups(dir, ID); assert.ok(L.filter(x => x.reason === 'pre-restore').length <= 4); assert.ok(L.some(x => x.reason === 'manual'));
});
test('cmpVer', () => { assert.equal(B.cmpVer('1.2.0', '1.10.0'), -1); assert.equal(B.cmpVer('2.0.0', '1.9.9'), 1); assert.equal(B.cmpVer('1.0', '1.0.0'), 0); });
