'use strict';
const { app, BrowserWindow, Menu, Tray, nativeImage, dialog, ipcMain, shell, clipboard } = require('electron');
const path = require('path'), fs = require('fs'), os = require('os');
const B = require('./backup.js');
const CFG = require('./app.config.json');
const VERSION = fs.readFileSync(path.join(__dirname, 'VERSION'), 'utf8').trim();
const SMOKE = process.env.APP_SMOKE === '1';
const DAY = 864e5;

let win = null, tray = null, closing = false, quitting = false;

/* ---------- journal (rotatif : 1 Mo x 3) ---------- */
const logDir = () => path.join(app.getPath('userData'), 'logs'), logFile = () => path.join(logDir(), 'app.log');
function log(level, msg) {
  try {
    fs.mkdirSync(logDir(), { recursive: true });
    const f = logFile();
    try { if (fs.statSync(f).size > 1048576) { for (let i = 2; i >= 1; i--) { try { fs.renameSync(f + (i > 1 ? '.' + (i - 1) : ''), f + '.' + i); } catch (e) { } } } } catch (e) { }
    fs.appendFileSync(f, `${new Date().toISOString()} [${level}] ${msg}\n`);
  } catch (e) { }
}
process.on('uncaughtException', e => { log('ERROR', 'uncaught: ' + (e && e.stack || e)); try { if (!SMOKE) dialog.showErrorBox(CFG.title, 'حدث خطأ غير متوقع:\n' + (e && e.message || e) + '\n\nالتفاصيل في: ' + logFile()); } catch (x) { } });
process.on('unhandledRejection', e => log('ERROR', 'rejection: ' + (e && e.stack || e)));

/* ---------- état local (dossier 2, dernière version lancée) ---------- */
const stateFile = () => path.join(app.getPath('userData'), 'desk.json');
function getState() { try { return JSON.parse(fs.readFileSync(stateFile(), 'utf8')); } catch (e) { return {}; } }
function setState(p) { const s = Object.assign(getState(), p); try { fs.writeFileSync(stateFile(), JSON.stringify(s)); } catch (e) { log('WARN', 'state: ' + e.message); } return s; }

/* ---------- dossiers de sauvegarde ---------- */
const dir1 = () => path.join(app.getPath('userData'), 'backups');
const dir2 = () => { const s = getState(); return s.dir2 === null ? null : (s.dir2 || path.join(app.getPath('documents'), CFG.dataFolder)); };
const dirs = () => [dir1(), dir2()].filter(Boolean);
const KEEP = { daily: 14, monthly: 6, pre: 5 };

function lastBackup() { const L = B.listBackups(dir1(), CFG.id); return L[0] || null; }
function status() {
  const l = lastBackup(), L = B.listBackups(dir1(), CFG.id);
  return { version: VERSION, dir1: dir1(), dir2: dir2(), count: L.length, last: l ? { name: l.name, reason: l.reason, at: l.mtime, size: l.size } : null,
    ageDays: l ? Math.floor((Date.now() - l.mtime) / DAY) : null, userData: app.getPath('userData') };
}
async function readData() {
  if (!win || win.isDestroyed()) throw new Error('النافذة غير جاهزة');
  const s = await win.webContents.executeJavaScript(`(window.flush&&flush(1),localStorage.getItem(${JSON.stringify(CFG.storageKey)})||(window.D?JSON.stringify(window.D):null))`);
  if (!s) throw new Error('لا توجد بيانات بعد');
  return s;
}
async function doBackup(reason, data) {
  const s = data || await readData();
  const r = B.createBackup({ data: s, appId: CFG.id, version: VERSION, schema: CFG.schema, reason, dirs: dirs(), keep: KEEP });
  log('INFO', `backup ${reason}: ${r.name} (${r.files.length} dossier(s))` + (r.warnings.length ? ' WARN ' + r.warnings.join(' | ') : ''));
  if (win && !win.isDestroyed()) win.webContents.executeJavaScript(`window.deskNote&&deskNote(${JSON.stringify(status())})`).catch(() => { });
  return r;
}

/* ---------- restauration ---------- */
async function doRestore(file) {
  if (!file) {
    const r = await dialog.showOpenDialog(win, { title: 'اختر نسخة احتياطية', defaultPath: dir1(), filters: [{ name: 'نسخة احتياطية', extensions: ['zip'] }], properties: ['openFile'] });
    if (r.canceled || !r.filePaths.length) return { cancel: true };
    file = r.filePaths[0];
  }
  let v; try { v = B.verifyBackup(fs.readFileSync(file), { appId: CFG.id, version: VERSION, schema: CFG.schema }); } catch (e) { v = { ok: false, error: e.message }; }
  if (!v.ok) { log('WARN', 'restore refused: ' + v.error); return { error: v.error }; }
  const m = v.manifest, when = new Date(m.created).toLocaleString('ar-MA'), cnt = Object.entries(m.counts || {}).filter(([, n]) => n).map(([k, n]) => `${k}: ${n}`).join(' · ');
  const c = await dialog.showMessageBox(win, { type: 'warning', buttons: ['استرجاع', 'إلغاء'], defaultId: 1, cancelId: 1, title: 'استرجاع نسخة احتياطية',
    message: 'سيتم استبدال كل البيانات الحالية بمحتوى النسخة.', detail: `تاريخ النسخة: ${when}\n${cnt}\n\nسيُنشأ أولاً نسخة أمان من بياناتك الحالية.` });
  if (c.response !== 0) return { cancel: true };
  try { await doBackup('pre-restore'); } catch (e) { log('WARN', 'pre-restore backup: ' + e.message); const g = await dialog.showMessageBox(win, { type: 'error', buttons: ['متابعة بدون نسخة أمان', 'إلغاء'], defaultId: 1, cancelId: 1, message: 'تعذّر إنشاء نسخة الأمان: ' + e.message }); if (g.response !== 0) return { cancel: true }; }
  await win.webContents.executeJavaScript(`window.__nf=1;localStorage.setItem(${JSON.stringify(CFG.storageKey)},${JSON.stringify(v.data)});if(window.__cl)localStorage.setItem('cl_restored','1');location.reload()`);
  log('INFO', 'restored from ' + file);
  return { ok: true, older: v.older };
}

/* ---------- diagnostics ---------- */
function diagText() {
  let tail = ''; try { tail = fs.readFileSync(logFile(), 'utf8').split('\n').slice(-200).join('\n'); } catch (e) { }
  const s = status();
  return [`${CFG.title} v${VERSION}`, `Electron ${process.versions.electron} / Node ${process.versions.node} / Chrome ${process.versions.chrome}`, `${os.type()} ${os.release()} ${os.arch()}`,
    `userData: ${s.userData}`, `backups: ${s.dir1} (${s.count})`, `backups2: ${s.dir2 || '-'}`, `last: ${s.last ? s.last.name : '-'}`, '--- log ---', tail].join('\n');
}

/* ---------- IPC ---------- */
const safe = fn => async (...a) => { try { return await fn(...a); } catch (e) { log('ERROR', e.stack || e.message); return { error: e.message }; } };
ipcMain.handle('bk:now', safe(async () => { const r = await doBackup('manual'); return { ok: true, name: r.name, warnings: r.warnings, status: status() }; }));
ipcMain.handle('bk:status', safe(async () => status()));
ipcMain.handle('bk:restore', safe(() => doRestore()));
ipcMain.handle('bk:open', safe(async () => { fs.mkdirSync(dir1(), { recursive: true }); await shell.openPath(dir1()); return { ok: true }; }));
ipcMain.handle('bk:dir2', safe(async (_e, clear) => {
  if (clear) setState({ dir2: null });
  else { const r = await dialog.showOpenDialog(win, { title: 'مجلد النسخ الثاني (فلاشة / قرص خارجي / OneDrive)', properties: ['openDirectory', 'createDirectory'] }); if (r.canceled || !r.filePaths.length) return { cancel: true }; setState({ dir2: r.filePaths[0] }); }
  return { ok: true, status: status() };
}));
ipcMain.handle('diag', safe(async () => { const t = diagText(); clipboard.writeText(t); return { ok: true, length: t.length }; }));

/* ---------- fenêtre ---------- */
function createWindow() {
  Menu.setApplicationMenu(null);
  win = new BrowserWindow({ width: 1300, height: 850, show: !SMOKE, autoHideMenuBar: true, icon: path.join(__dirname, 'build', 'icon.png'), title: CFG.title,
    webPreferences: { contextIsolation: true, sandbox: true, spellcheck: false, preload: path.join(__dirname, 'preload.js') } });
  if (!SMOKE) win.maximize();
  win.webContents.on('did-fail-load', (_e, code, desc) => { log('ERROR', `did-fail-load ${code} ${desc}`); if (!SMOKE) dialog.showErrorBox(CFG.title, 'تعذّر تحميل الواجهة: ' + desc); });
  win.webContents.on('render-process-gone', (_e, d) => log('ERROR', 'render-process-gone ' + d.reason));
  win.loadFile(path.join(__dirname, 'index.html'));
  win.on('close', async e => {
    if (closing) return; e.preventDefault(); closing = true;
    const t = setTimeout(() => win.destroy(), 5000);
    try {
      const data = await readData();                                 // flush + lecture
      const l = lastBackup();
      if (!l || Date.now() - l.mtime > DAY) await doBackup('exit', data);   // sauvegarde à la sortie si > 24 h
    } catch (err) { log('WARN', 'exit backup: ' + err.message); }
    clearTimeout(t); win.destroy();
  });
}
function showWin() { if (!win) return; if (win.isMinimized()) win.restore(); win.show(); win.focus(); }

function createTray() {
  try {
    const img = nativeImage.createFromPath(path.join(__dirname, 'build', 'icon.png')).resize({ width: 16, height: 16 });
    tray = new Tray(img); tray.setToolTip(CFG.title);
    tray.setContextMenu(Menu.buildFromTemplate([
      { label: 'فتح', click: showWin },
      { label: 'نسخة احتياطية الآن', click: async () => { try { const r = await doBackup('manual'); dialog.showMessageBox({ type: 'info', message: 'تم إنشاء النسخة الاحتياطية', detail: r.name }); } catch (e) { dialog.showErrorBox(CFG.title, e.message); } } },
      { label: 'فتح مجلد النسخ', click: () => { fs.mkdirSync(dir1(), { recursive: true }); shell.openPath(dir1()); } },
      { type: 'separator' }, { label: 'خروج', click: () => { quitting = true; app.quit(); } }]));
    tray.on('click', showWin);
  } catch (e) { log('WARN', 'tray: ' + e.message); }
}

/* ---------- planificateur interne (pendant que le programme est ouvert) ---------- */
function scheduler() {
  setInterval(async () => {
    try { const l = lastBackup(); if (!l || Date.now() - l.mtime > DAY) await doBackup('auto'); } catch (e) { log('WARN', 'auto backup: ' + e.message); }
  }, 15 * 60 * 1000);
}

/* ---------- démarrage ---------- */
async function smoke() {
  const out = process.env.SMOKE_OUT || path.join(os.tmpdir(), 'smoke.json'), res = { app: CFG.id, version: VERSION, steps: [] };
  try {
    await new Promise(r => win.webContents.once('did-finish-load', r)); res.steps.push('loaded');
    await new Promise(r => setTimeout(r, 1500));
    const r = await doBackup('manual'); res.steps.push('backup:' + r.name);
    const v = B.verifyBackup(fs.readFileSync(r.file), { appId: CFG.id, version: VERSION, schema: CFG.schema });
    if (!v.ok) throw new Error('verify: ' + v.error); res.steps.push('verified'); res.ok = true;
  } catch (e) { res.ok = false; res.error = e.message; }
  fs.writeFileSync(out, JSON.stringify(res, null, 2)); closing = true; app.exit(res.ok ? 0 : 1);
}

if (!SMOKE && !app.requestSingleInstanceLock()) { app.quit(); }
else {
  app.on('second-instance', showWin);
  app.whenReady().then(async () => {
    log('INFO', `start v${VERSION} ${process.platform}`);
    createWindow();
    if (SMOKE) return smoke();
    createTray(); scheduler();
    const st = getState();
    if (st.lastVersion && st.lastVersion !== VERSION) {      // première ouverture après une mise à jour
      win.webContents.once('did-finish-load', () => setTimeout(() => doBackup('pre-update').catch(e => log('WARN', 'pre-update: ' + e.message)), 2000));
    }
    setState({ lastVersion: VERSION });
  });
  app.on('window-all-closed', () => { if (!SMOKE) app.quit(); });
}
