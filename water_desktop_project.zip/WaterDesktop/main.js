const { app, BrowserWindow, Menu } = require('electron');
const path = require('path');
const fs = require('fs');
let win, closing = false;
function writeBackup(s) {
  try {
    if (!s) return;
    const d = path.join(app.getPath('documents'), 'WaterApp-AutoBackup');
    fs.mkdirSync(d, { recursive: true });
    fs.writeFileSync(path.join(d, 'auto-' + new Date().toISOString().slice(0, 10) + '.json'), s);
    const L = fs.readdirSync(d).filter(x => /^auto-.*\.json$/.test(x)).sort();
    while (L.length > 10) fs.unlinkSync(path.join(d, L.shift()));
  } catch (e) {}
}
function createWindow() {
  Menu.setApplicationMenu(null);
  win = new BrowserWindow({
    width: 1300, height: 850, autoHideMenuBar: true,
    icon: path.join(__dirname, 'build', 'icon.png'),
    webPreferences: { contextIsolation: true, spellcheck: false }
  });
  win.maximize();
  win.loadFile(path.join(__dirname, 'index.html'));
  win.on('close', (e) => {
    if (closing) return;
    e.preventDefault();
    closing = true;
    const t = setTimeout(() => win.destroy(), 3000);
    win.webContents.executeJavaScript('(window.flush && flush(1), localStorage.getItem("w1"))')
      .then(writeBackup).catch(() => {}).finally(() => { clearTimeout(t); win.destroy(); });
  });
}
app.whenReady().then(createWindow);
app.on('window-all-closed', () => app.quit());
