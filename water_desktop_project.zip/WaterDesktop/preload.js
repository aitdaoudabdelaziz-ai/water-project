'use strict';
const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('desk', {
  backupNow: () => ipcRenderer.invoke('bk:now'),
  status: () => ipcRenderer.invoke('bk:status'),
  restore: () => ipcRenderer.invoke('bk:restore'),
  openFolder: () => ipcRenderer.invoke('bk:open'),
  pickDir2: () => ipcRenderer.invoke('bk:dir2'),
  clearDir2: () => ipcRenderer.invoke('bk:dir2', true),
  diagnostics: () => ipcRenderer.invoke('diag')
});
