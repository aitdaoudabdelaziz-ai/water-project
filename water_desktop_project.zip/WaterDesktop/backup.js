'use strict';
/* Moteur de sauvegarde — Node pur (aucune dépendance, indépendant d'Electron).
   Une sauvegarde = un .zip contenant :
     data.json      instantané cohérent des données (localStorage de l'application)
     manifest.json  { app, version, schema, created, reason, files:{ 'data.json':{sha256,bytes} }, counts }
*/
const fs = require('fs'), path = require('path'), zlib = require('zlib'), crypto = require('crypto');

/* ---------- CRC32 + ZIP minimal (deflate) ---------- */
const CRC_T = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
function crc32(buf) { let c = 0xFFFFFFFF; for (let i = 0; i < buf.length; i++) c = CRC_T[(c ^ buf[i]) & 255] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; }

function dosDateTime(d) {
  const time = (d.getHours() << 11) | (d.getMinutes() << 5) | (d.getSeconds() >> 1);
  const date = ((d.getFullYear() - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate();
  return { time, date };
}
function makeZip(entries, when = new Date()) {
  const { time, date } = dosDateTime(when), locals = [], centrals = []; let offset = 0;
  for (const e of entries) {
    const name = Buffer.from(e.name, 'utf8'), data = Buffer.isBuffer(e.data) ? e.data : Buffer.from(e.data);
    const comp = zlib.deflateRawSync(data), crc = crc32(data);
    const lh = Buffer.alloc(30);
    lh.writeUInt32LE(0x04034b50, 0); lh.writeUInt16LE(20, 4); lh.writeUInt16LE(0x0800, 6); lh.writeUInt16LE(8, 8);
    lh.writeUInt16LE(time, 10); lh.writeUInt16LE(date, 12); lh.writeUInt32LE(crc, 14);
    lh.writeUInt32LE(comp.length, 18); lh.writeUInt32LE(data.length, 22); lh.writeUInt16LE(name.length, 26); lh.writeUInt16LE(0, 28);
    locals.push(lh, name, comp);
    const ch = Buffer.alloc(46);
    ch.writeUInt32LE(0x02014b50, 0); ch.writeUInt16LE(20, 4); ch.writeUInt16LE(20, 6); ch.writeUInt16LE(0x0800, 8); ch.writeUInt16LE(8, 10);
    ch.writeUInt16LE(time, 12); ch.writeUInt16LE(date, 14); ch.writeUInt32LE(crc, 16); ch.writeUInt32LE(comp.length, 20);
    ch.writeUInt32LE(data.length, 24); ch.writeUInt16LE(name.length, 28); ch.writeUInt32LE(offset, 42);
    centrals.push(ch, name);
    offset += 30 + name.length + comp.length;
  }
  const cd = Buffer.concat(centrals), end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0); end.writeUInt16LE(entries.length, 8); end.writeUInt16LE(entries.length, 10);
  end.writeUInt32LE(cd.length, 12); end.writeUInt32LE(offset, 16);
  return Buffer.concat([...locals, cd, end]);
}
function readZip(buf) {
  let eocd = -1;
  for (let i = buf.length - 22; i >= Math.max(0, buf.length - 65557); i--) if (buf.readUInt32LE(i) === 0x06054b50) { eocd = i; break; }
  if (eocd < 0) throw new Error('ملف zip غير صالح');
  const count = buf.readUInt16LE(eocd + 10); let p = buf.readUInt32LE(eocd + 16); const out = new Map();
  for (let n = 0; n < count; n++) {
    if (buf.readUInt32LE(p) !== 0x02014b50) throw new Error('ملف zip تالف');
    const method = buf.readUInt16LE(p + 10), crc = buf.readUInt32LE(p + 16), csize = buf.readUInt32LE(p + 20), usize = buf.readUInt32LE(p + 24);
    const nl = buf.readUInt16LE(p + 28), el = buf.readUInt16LE(p + 30), cl = buf.readUInt16LE(p + 32), lo = buf.readUInt32LE(p + 42);
    const name = buf.toString('utf8', p + 46, p + 46 + nl);
    if (buf.readUInt32LE(lo) !== 0x04034b50) throw new Error('ملف zip تالف');
    const start = lo + 30 + buf.readUInt16LE(lo + 26) + buf.readUInt16LE(lo + 28), raw = buf.subarray(start, start + csize);
    if (raw.length !== csize) throw new Error('ملف zip مقطوع');
    const data = method === 8 ? zlib.inflateRawSync(raw) : method === 0 ? Buffer.from(raw) : null;
    if (!data) throw new Error('طريقة ضغط غير مدعومة');
    if (data.length !== usize || crc32(data) !== crc) throw new Error('فشل التحقق من سلامة الملف داخل الأرشيف: ' + name);
    out.set(name, data); p += 46 + nl + el + cl;
  }
  return out;
}

/* ---------- versions ---------- */
function cmpVer(a, b) { const x = String(a).split('.').map(Number), y = String(b).split('.').map(Number); for (let i = 0; i < 3; i++) { const d = (x[i] || 0) - (y[i] || 0); if (d) return d > 0 ? 1 : -1; } return 0; }

/* ---------- counts (generic: arrays -> length, objects -> keys) ---------- */
function countsOf(obj) { const c = {}; if (obj && typeof obj === 'object') for (const k of Object.keys(obj)) { const v = obj[k]; if (Array.isArray(v)) c[k] = v.length; else if (v && typeof v === 'object') c[k] = Object.keys(v).length; } return c; }

/* ---------- create ---------- */
const pad = n => String(n).padStart(2, '0');
function stamp(d) { return d.getFullYear() + pad(d.getMonth() + 1) + pad(d.getDate()) + '-' + pad(d.getHours()) + pad(d.getMinutes()) + pad(d.getSeconds()); }
function createBackup({ data, appId, version, schema = 1, reason = 'manual', dirs, keep, now = new Date() }) {
  if (typeof data !== 'string' || !data.length) throw new Error('لا توجد بيانات للنسخ');
  let parsed; try { parsed = JSON.parse(data); } catch (e) { throw new Error('البيانات الحالية غير صالحة'); }
  const dbuf = Buffer.from(data, 'utf8');
  const manifest = { app: appId, version, schema, created: now.toISOString(), reason,
    files: { 'data.json': { sha256: crypto.createHash('sha256').update(dbuf).digest('hex'), bytes: dbuf.length } }, counts: countsOf(parsed) };
  const zip = makeZip([{ name: 'manifest.json', data: JSON.stringify(manifest, null, 2) }, { name: 'data.json', data: dbuf }], now);
  const name = `${appId}-${stamp(now)}-${reason}.zip`, written = [], warnings = [];
  (dirs || []).filter(Boolean).forEach((dir, i) => {
    try {
      fs.mkdirSync(dir, { recursive: true });
      const tmp = path.join(dir, name + '.tmp'), dst = path.join(dir, name);
      fs.writeFileSync(tmp, zip); fs.renameSync(tmp, dst); written.push(dst);
      if (keep) prune(dir, appId, keep);
    } catch (e) { warnings.push((i ? 'المجلد الثاني: ' : 'مجلد النسخ: ') + e.message); }
  });
  if (!written.length) throw new Error('تعذّر كتابة النسخة الاحتياطية. ' + warnings.join(' | '));
  return { file: written[0], name, files: written, warnings, manifest };
}

/* ---------- verify ---------- */
function verifyBackup(buf, { appId, version, schema = 1 }) {
  let z; try { z = readZip(buf); } catch (e) { return { ok: false, error: e.message }; }
  if (!z.has('manifest.json') || !z.has('data.json')) return { ok: false, error: 'هذا الملف ليس نسخة احتياطية لهذا البرنامج' };
  let m; try { m = JSON.parse(z.get('manifest.json').toString('utf8')); } catch (e) { return { ok: false, error: 'بيان النسخة (manifest) تالف' }; }
  if (m.app !== appId) return { ok: false, error: 'هذه النسخة تخص برنامجاً آخر (' + m.app + ')' };
  if (m.schema > schema || cmpVer(m.version, version) > 0) return { ok: false, error: `هذه النسخة أنشأها إصدار أحدث من البرنامج (${m.version}). حدّث البرنامج أولاً، حتى لا تضيع بيانات.` };
  const d = z.get('data.json'), sha = crypto.createHash('sha256').update(d).digest('hex');
  if (!m.files || !m.files['data.json'] || m.files['data.json'].sha256 !== sha) return { ok: false, error: 'بصمة التحقق (checksum) لا تطابق: الملف تالف أو معدَّل' };
  const text = d.toString('utf8'); try { JSON.parse(text); } catch (e) { return { ok: false, error: 'محتوى البيانات غير صالح' }; }
  return { ok: true, data: text, manifest: m, older: m.schema < schema || cmpVer(m.version, version) < 0 };
}

/* ---------- list / prune ---------- */
function listBackups(dir, appId) {
  let L = []; try { L = fs.readdirSync(dir); } catch (e) { return []; }
  const re = new RegExp('^' + appId.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '-(\\d{8})-(\\d{6})-([a-z-]+)\\.zip$');
  return L.map(n => { const m = re.exec(n); if (!m) return null; const f = path.join(dir, n), st = fs.statSync(f); return { name: n, path: f, day: m[1], key: m[1] + m[2], reason: m[3], size: st.size, mtime: st.mtimeMs }; })
    .filter(Boolean).sort((a, b) => (a.key < b.key ? 1 : -1));
}
function prune(dir, appId, { daily = 14, monthly = 6, pre = 5 } = {}) {
  const L = listBackups(dir, appId); if (L.length < 2) return [];
  const keep = new Set([L[0].name]);                                    // jamais la dernière
  L.filter(x => !x.reason.startsWith('pre-')).slice(0, daily).forEach(x => keep.add(x.name));
  const months = new Map(); L.forEach(x => { const k = x.day.slice(0, 6); if (!months.has(k)) months.set(k, x); });
  [...months.values()].slice(0, monthly).forEach(x => keep.add(x.name)); // la plus récente de chaque mois
  L.filter(x => x.reason.startsWith('pre-')).slice(0, pre).forEach(x => keep.add(x.name));
  const gone = []; L.forEach(x => { if (!keep.has(x.name)) { try { fs.unlinkSync(x.path); gone.push(x.name); } catch (e) { } } });
  return gone;
}
module.exports = { crc32, makeZip, readZip, createBackup, verifyBackup, listBackups, prune, cmpVer, countsOf };
