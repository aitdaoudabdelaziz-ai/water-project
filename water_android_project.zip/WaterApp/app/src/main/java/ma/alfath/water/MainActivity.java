package ma.alfath.water;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.JsPromptResult;
import android.webkit.JsResult;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.webkit.WebViewAssetLoader;

import java.io.InputStream;
import java.io.OutputStream;

public class MainActivity extends AppCompatActivity {

    private static final String HOST = "appassets.androidplatform.net";
    private static final String SHEETJS = "https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js";

    // يُحقن في الصفحة: يجعل window.print() وتنزيلات الملفات (blob) تعمل داخل WebView
    private static final String PATCH =
        "(function(){if(window.__ab)return;window.__ab=1;" +
        "window.print=function(){var s=document.querySelector('#pp .pg')?'A5L':(document.querySelector('#pp .rp')?'A4L':'A4');AndroidBridge.print(s)};" +
        "function grab(a){var n=a.download||'download';fetch(a.href).then(function(r){return r.blob()}).then(function(b){var f=new FileReader();" +
        "f.onloadend=function(){AndroidBridge.save(n,b.type||'application/octet-stream',String(f.result).split(',')[1])};f.readAsDataURL(b)})" +
        ".catch(function(){AndroidBridge.toast('تعذّر الحفظ')})}" +
        "var oc=HTMLAnchorElement.prototype.click,od=HTMLAnchorElement.prototype.dispatchEvent;" +
        "HTMLAnchorElement.prototype.click=function(){if(this.download&&this.href.indexOf('blob:')==0){grab(this);return}return oc.apply(this,arguments)};" +
        "HTMLAnchorElement.prototype.dispatchEvent=function(e){if(e&&e.type=='click'&&this.download&&this.href.indexOf('blob:')==0){grab(this);return true}return od.apply(this,arguments)};" +
        "})();";

    private WebView web;
    private ValueCallback<Uri[]> fileCb;

    private final ActivityResultLauncher<Intent> chooser = registerForActivityResult(
        new ActivityResultContracts.StartActivityForResult(), res -> {
            if (fileCb != null) {
                fileCb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res.getResultCode(), res.getData()));
                fileCb = null;
            }
        });

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        web = new WebView(this);
        setContentView(web);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);

        web.addJavascriptInterface(new Bridge(), "AndroidBridge");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (SHEETJS.equals(u.toString())) {          // مكتبة Excel من الملفات المحلية (دون إنترنت)
                    try {
                        InputStream in = getAssets().open("xlsx.full.min.js");
                        return new WebResourceResponse("application/javascript", "UTF-8", in);
                    } catch (Exception e) {
                        return null;                          // غير موجودة: يحاول الشبكة إن توفرت
                    }
                }
                return loader.shouldInterceptRequest(u);
            }

            @Override
            public void onPageFinished(WebView v, String url) {
                v.evaluateJavascript(PATCH, null);
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onJsAlert(WebView v, String url, String msg, final JsResult r) {
                new AlertDialog.Builder(MainActivity.this).setMessage(msg)
                    .setPositiveButton("موافق", (d, w) -> r.confirm())
                    .setOnCancelListener(d -> r.cancel()).show();
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView v, String url, String msg, final JsResult r) {
                new AlertDialog.Builder(MainActivity.this).setMessage(msg)
                    .setPositiveButton("موافق", (d, w) -> r.confirm())
                    .setNegativeButton("إلغاء", (d, w) -> r.cancel())
                    .setOnCancelListener(d -> r.cancel()).show();
                return true;
            }

            @Override
            public boolean onJsPrompt(WebView v, String url, String msg, String def, final JsPromptResult r) {
                final EditText e = new EditText(MainActivity.this);
                e.setText(def);
                new AlertDialog.Builder(MainActivity.this).setMessage(msg).setView(e)
                    .setPositiveButton("موافق", (d, w) -> r.confirm(e.getText().toString()))
                    .setNegativeButton("إلغاء", (d, w) -> r.cancel())
                    .setOnCancelListener(d -> r.cancel()).show();
                return true;
            }

            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb;
                try {
                    chooser.launch(p.createIntent());
                } catch (Exception e) {
                    fileCb = null;
                    return false;
                }
                return true;
            }
        });

        // احتياط: إن وصل تنزيل blob دون المرور بالحقن
        web.setDownloadListener((url, ua, cd, mime, len) -> {
            if (url.startsWith("blob:")) {
                String name = URLUtil.guessFileName(url, cd, mime).replace("'", "");
                String js = "fetch('" + url + "').then(function(r){return r.blob()}).then(function(b){var f=new FileReader();" +
                    "f.onloadend=function(){AndroidBridge.save('" + name + "',b.type||'application/octet-stream',String(f.result).split(',')[1])};f.readAsDataURL(b)})";
                web.evaluateJavascript(js, null);
            }
        });

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                web.evaluateJavascript(
                    "(function(){var p=document.getElementById('pv');if(p&&p.style.display==='block'){p.style.display='none';return 'c'}return 'x'})()",
                    v -> {
                        if (!"\"c\"".equals(v)) {
                            setEnabled(false);
                            MainActivity.this.getOnBackPressedDispatcher().onBackPressed();
                        }
                    });
            }
        });

        web.loadUrl("https://" + HOST + "/assets/index.html");
    }

    private Uri saveToDownloads(String name, String mime, byte[] data) throws Exception {
        ContentValues v = new ContentValues();
        v.put(MediaStore.Downloads.DISPLAY_NAME, name);
        v.put(MediaStore.Downloads.MIME_TYPE, mime);
        v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
        Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
        if (uri == null) throw new Exception("insert failed");
        try (OutputStream os = getContentResolver().openOutputStream(uri)) {
            os.write(data);
        }
        return uri;
    }

    private void share(Uri uri, String mime) {
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType(mime);
        i.putExtra(Intent.EXTRA_STREAM, uri);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(i, "مشاركة"));
    }

    public class Bridge {
        @JavascriptInterface
        public void print(final String size) {
            runOnUiThread(() -> {
                PrintManager pm = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                String job = getString(R.string.app_name);
                PrintAttributes.MediaSize ms = PrintAttributes.MediaSize.ISO_A4;
                if ("A5L".equals(size)) ms = PrintAttributes.MediaSize.ISO_A5.asLandscape();
                if ("A4L".equals(size)) ms = PrintAttributes.MediaSize.ISO_A4.asLandscape();
                PrintAttributes attrs = new PrintAttributes.Builder().setMediaSize(ms).build();
                PrintDocumentAdapter ad = web.createPrintDocumentAdapter(job);
                pm.print(job, ad, attrs);
            });
        }

        @JavascriptInterface
        public void save(final String name, final String mime, String b64) {
            try {
                byte[] data = Base64.decode(b64, Base64.DEFAULT);
                final Uri uri = saveToDownloads(name, mime, data);
                runOnUiThread(() -> new AlertDialog.Builder(MainActivity.this)
                    .setMessage("تم حفظ الملف في مجلد التنزيلات (Downloads):\n" + name)
                    .setPositiveButton("مشاركة", (d, w) -> share(uri, mime))
                    .setNegativeButton("موافق", null).show());
            } catch (Exception e) {
                toast("تعذّر حفظ الملف");
            }
        }

        @JavascriptInterface
        public void toast(final String m) {
            runOnUiThread(() -> Toast.makeText(MainActivity.this, m, Toast.LENGTH_LONG).show());
        }
    }
}
