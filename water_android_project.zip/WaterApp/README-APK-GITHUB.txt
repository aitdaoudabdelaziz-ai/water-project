بناء ملف APK دون Android Studio (عبر GitHub مجاناً)
1) أنشئ حساباً على github.com ثم New repository (اجعله Private).
2) في صفحة المستودع: Add file > Upload files، ثم اسحب *محتويات* هذا المجلد (وليس المجلد نفسه).
3) مجلد .github قد لا يُرفع بالسحب. في هذه الحالة: Add file > Create new file،
   اكتب الاسم  .github/workflows/build.yml  والصق فيه محتوى الملف build-apk.yml المرفق، ثم Commit.
4) افتح تبويب Actions: يبدأ البناء تلقائياً (5-10 دقائق). عند ظهور علامة ✔ الخضراء
   افتح العملية ثم نزّل من قسم Artifacts الملف apk (zip) وفُكّه، فتجد app-debug.apk.
5) انقل app-debug.apk إلى الهاتف وثبّته (اسمح بالتثبيت من مصادر غير معروفة).
